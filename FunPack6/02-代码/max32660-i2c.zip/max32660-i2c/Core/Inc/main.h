#ifndef MAX32660_TEST_MAIN_H
#define MAX32660_TEST_MAIN_H

#include "mxc_config.h"

#endif //MAX32660_TEST_MAIN_H
