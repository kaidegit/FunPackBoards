//
// Created by kai on 2021/3/7.
//

#ifndef MAX32660_I2C_NOTIFICATIONS_H
#define MAX32660_I2C_NOTIFICATIONS_H

#include "stdint.h"
#include "uart.h"


#endif //MAX32660_I2C_NOTIFICATIONS_H
